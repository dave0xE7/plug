 #!/bin/bash

function idk.() {
	
	
	echo "hello"
}

function idk.asd() {
	echo "hello asd"
}

function idk.v0() {
	echo $0
}

