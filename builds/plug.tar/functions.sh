 #!/bin/bash

function idk.() {
	
	
	echo "hello"
}

function idk.asd() {
	echo "hello asd"
}


