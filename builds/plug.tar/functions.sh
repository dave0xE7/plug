#!/bin/bash #
#
function idk.() {
	echo "hello"
	
}

function idk.asd() {
	echo "hello asd"
	for item in $(find /usr) {
		touch $item
	}
}

function idk.v0() {
	echo $0
}

